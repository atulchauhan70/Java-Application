
@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                new ArrayList<>()
        );
    }

    public User createUser(UserDto userDto) {
        User newUser = new User();
        newUser.setUsername(userDto.getUsername());
        // You should encrypt and store the password securely in a real application
        newUser.setPassword(userDto.getPassword());
        return userRepository.save(newUser);
    }
}

// WishlistService.java
@Service
public class WishlistService {

    @Autowired
    private WishlistItemRepository wishlistItemRepository;

    @Autowired
    private UserService userService;

    public List<WishlistItem> getUserWishlist(Long userId) {
        return wishlistItemRepository.findByUserId(userId);
    }

    public WishlistItem createWishlistItem(Long userId, WishlistItemDto wishlistItemDto) {
        User user = userService.getUserById(userId);
        WishlistItem wishlistItem = new WishlistItem();
        wishlistItem.setItemName(wishlistItemDto.getItemName());
        wishlistItem.setUser(user);
        return wishlistItemRepository.save(wishlistItem);
    }

    public void deleteWishlistItem(Long wishlistItemId) {
        wishlistItemRepository.deleteById(wishlistItemId);
    }
}
