
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody UserDto userDto) {
        userService.createUser(userDto);
        return ResponseEntity.ok("User registered successfully");
    }
}

// WishlistController.java
@RestController
@RequestMapping("/api/wishlists")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @GetMapping
    public ResponseEntity<List<WishlistItem>> getUserWishlist() {
        // You can obtain the user ID from the authenticated user's context
        Long userId = 1L; // Replace with actual user ID retrieval logic
        List<WishlistItem> wishlist = wishlistService.getUserWishlist(userId);
        return ResponseEntity.ok(wishlist);
    }

    @PostMapping
    public ResponseEntity<String> createWishlistItem(@RequestBody WishlistItemDto wishlistItemDto) {
        Long userId = 1L; // Replace with actual user ID retrieval logic
        wishlistService.createWishlistItem(userId, wishlistItemDto);
        return ResponseEntity.ok("Wishlist item created successfully");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteWishlistItem(@PathVariable Long id) {
        wishlistService.deleteWishlistItem(id);
        return ResponseEntity.ok("Wishlist item deleted successfully");
    }
}
