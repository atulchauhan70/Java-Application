
public class UserDto {

    private String username;

    private String password;

    // constructors, getters, setters
}

// WishlistItemDto.java
public class WishlistItemDto {

    private String itemName;

    // constructors, getters, setters
}
